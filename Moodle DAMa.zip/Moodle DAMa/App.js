import { StatusBar } from 'react-native'
import { createNativeStackNavigator } from '@react-navigation/native-stack'
import HomeScreen from './src/screens/HomeScreen'
import ComponentsScreen from './src/screens/ComponentScreen'
import ListScreen from './src/screens/ListScreen'
import { NavigationContainer } from '@react-navigation/native'
import Login from './src/Login'
import UserDetails from './src/screens/UserDetails'
import About from './src/About'
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs' 
import FontAwesome from '@expo/vector-icons/FontAwesome5'


const Tab = createBottomTabNavigator()

export default function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator initialRouteName="Home">
        <Tab.Screen name="Home" component={HomeScreen} 
        
        options={{
          tabBarIcon: () => {
            return <FontAwesome name='home' size={20} />
          },
          tabBarActiveTintColor: '#2196f3',
          tabBarInactiveTintColor: '#707d87',
        }}
        
        
        
        />
        
        <Tab.Screen name="Components" component={ComponentsScreen} />
        <Tab.Screen name='Login' component={Login} />
        <Tab.Screen name='About' component={About} />
        <Tab.Screen name='UserDetails' component={UserDetails} />
      </Tab.Navigator>
      <StatusBar style="auto"/>
    </NavigationContainer>
  )
}