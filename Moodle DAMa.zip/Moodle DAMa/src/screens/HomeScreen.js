import React from 'react'
import { Text, StyleSheet, View, Button, TouchableOpacity } from 'react-native'


const HomeScreen = (props) => {
  console.log(props)
  const navigation = props.navigation

  return (
    <View>
      <Text style={styles.text}>Welcome you'r name to our first project</Text>
      <Text style={styles.text}>;Now we can navigate between screen</Text>
      <Text style={styles.text}>How are you feelingx</Text>
      
      <Button
        onPress={() => {
          console.log('button pressed')
          navigation.navigate('About')
        }}
        title="Go to About" /> <br></br>
    <Button
        onPress={() => {
          console.log('button pressed')
          navigation.navigate('UserDetails')
        }}
        title="Go to UserDetails" />
      

    </View>
  )
}

const styles = StyleSheet.create({
  text: {
    fontSize: 17,
    paddingBottom:4
  }
})

export default HomeScreen