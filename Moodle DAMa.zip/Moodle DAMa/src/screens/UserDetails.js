import React from 'react'
import { Text, StyleSheet, View, Button, TouchableOpacity } from 'react-native'


const UserDetails = (props) => {
  console.log(props)
  const navigation = props.navigation

  return (
    <View>
     <h1>Name</h1>

     <Text>Your Completed name</Text>

     <h1>Age</h1>

     <Text>Your age</Text>

     <h1>email</h1>

     <Text>Your email</Text>
    
    </View>
  )
}

const styles = StyleSheet.create({
  text: {
    fontSize: 17,
    paddingBottom:4
  }
})

export default UserDetails