import React from 'react'
import { Text, StyleSheet, View, Button, TouchableOpacity } from 'react-native'


const About = (props) => {
  console.log(props)
  const navigation = props.navigation

  return (
    <View>
      <h1>About</h1>
        <Text> Developed by your completed name </Text>
      <h1>Version</h1>
        <Text>FirtApp version 1.0</Text>
    </View>
  )
}

const styles = StyleSheet.create({
  text: {
    fontSize: 17,
    paddingBottom:4
  }
})

export default About